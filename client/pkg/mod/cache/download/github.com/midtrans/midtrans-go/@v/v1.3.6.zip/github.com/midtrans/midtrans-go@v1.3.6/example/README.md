# Sample App
This is a very simple, very minimalist example to demonstrate integrating Midtrans with Go

## Run The app
1. Clone the repository, open terminal in this `/example/simple/coreapi-card-3ds` folder.
2. Run the web server using: `go run main.go`
3. The smple app will run at port 3000. Open `localhost:3000` from browser.

## Run command line app
1. Clone the repository, open terminal in this `/example/simple/coreapi` folder.
2. Run the app using: `go run main.go`
